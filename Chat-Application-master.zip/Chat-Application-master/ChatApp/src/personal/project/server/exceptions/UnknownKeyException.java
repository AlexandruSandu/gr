package personal.project.server.exceptions;

public class UnknownKeyException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnknownKeyException(String message) {
        super(message);
    }
    
}
