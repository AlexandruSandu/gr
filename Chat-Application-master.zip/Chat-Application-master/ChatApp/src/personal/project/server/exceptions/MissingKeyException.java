package personal.project.server.exceptions;

public class MissingKeyException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MissingKeyException(String message) {
        super(message);
    }
    
}
